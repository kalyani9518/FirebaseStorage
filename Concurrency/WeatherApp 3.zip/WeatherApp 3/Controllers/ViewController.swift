//
//  ViewController.swift
//  WeatherApp
//
//  Created by Admin on 04/02/22.
//

import UIKit
import CoreLocation
protocol DataPassProtocol:AnyObject{
    func dataPass(cityName:String?)
}

class ViewController: UIViewController,CLLocationManagerDelegate{
    @IBOutlet weak var searchTxt: UISearchBar!
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var weatherType: UILabel!
    @IBOutlet weak var currentCityTemp: UILabel!
    @IBOutlet weak var bgIamge: UIImageView!
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var date: UILabel!
    @IBOutlet weak var timelbl: UILabel!
    @IBOutlet weak var sunriseOutlet: UILabel!
    @IBOutlet weak var sunsetOutlet: UILabel!
    @IBOutlet weak var humadityOutlet: UILabel!
    @IBOutlet weak var contryOutlet: UILabel!
    @IBOutlet weak var windOutlet: UILabel!
    @IBOutlet weak var pressureOutlet: UILabel!
    @IBOutlet weak var minOutlet: UILabel!
    @IBOutlet weak var maxOutlet: UILabel!
    var weatherViewModel : WeatherViewModel!
//    let locationManager = CLLocationManager()
//    var currentLocation : CLLocation?
//    var lat : Double?
//    var  lon : Double?
//    var searchStr: String?
    weak var delegate : DataPassProtocol?
    override func viewDidLoad() {
        super.viewDidLoad()
        searchTxt.delegate = self
          }
    
    fileprivate func setWeatherInformation(_ currentTemp: CityWeatherInformation) {
        self.nameLbl.text = currentTemp.currentCity
        self.weatherType.text = currentTemp.currentType
        self.date.text = currentTemp.currentDate
        self.timelbl.text = currentTemp.currentTime
        self.currentCityTemp.text = currentTemp.currentCityTemp
        self.minOutlet.text = "Min : "+currentTemp.currentMin
        self.maxOutlet.text = "Min : "+currentTemp.currentMax
        self.weatherType.text = currentTemp.currentType
        self.sunsetOutlet.text = currentTemp.currentSunset
        self.sunriseOutlet.text = currentTemp.currentSunrise
        self.contryOutlet.text = currentTemp.currentCountry
        self.humadityOutlet.text = currentTemp.currentHumadity+"%"
        self.windOutlet.text = currentTemp.currentWindspeed + "km/h"
        self.pressureOutlet.text = currentTemp.currentPressure + "hPa"
    
    }
   
    private func config(name:String){
            self.weatherViewModel = WeatherViewModel()
        self.weatherViewModel.getData1(name: name)
            weatherViewModel!.sendDataToController = {
                DispatchQueue.main.async { [self] in
                    guard let currentTemp = self.weatherViewModel.cityWeatherInformation else{
                        return
                    }
                    self.setWeatherInformation(currentTemp)
                   
                }
          }
    }
}

extension ViewController : UISearchBarDelegate{
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        guard let searchBar = searchBar.text?.lowercased() else{
            return
        }
        config(name: searchBar)
        
    }
}

