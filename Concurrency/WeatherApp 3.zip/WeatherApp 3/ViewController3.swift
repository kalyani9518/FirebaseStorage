//
//  ViewController3.swift
//  WeatherApp
//
//  Created by Admin on 08/02/22.
//

import UIKit

class ViewController3: UIViewController {

    @IBOutlet weak var tblView: UITableView!
    let apiservice = ApiService()
    var watherInfo : WeatherInfo?
    override func viewDidLoad() {
        super.viewDidLoad()
        apiservice.getApi(cityName: "pune") { weatherInfo in
            self.watherInfo = weatherInfo
            self.tblView.reloadData()
        }
        
    }
    

}
extension ViewController3 : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tblView.dequeueReusableCell(withIdentifier: "TableViewCell1", for: indexPath) as? TableViewCell1{
           
            return cell
        }
        return UITableViewCell()
    }
    
    
}
